	</main>
	<footer class="main-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<ul class="main-footer__address">
						<li>
							Dharma Wanita Persatuan Kementerian Perhubungan
							Republik Indonesia
						</li>
						<li>
							Jl. Medan Merdeka Barat No. 8
							Jakarta Pusat
						</li>
					</ul>
				</div>
				<div class="col-md-5">
					<ul class="main-footer__contact">
						<li>
							<span class="fa fa-envelope"></span>
							dwp@kemenhub.com
						</li>
						<li>
							<span class="fa fa-phone"></span>
							(021) 7382 9123
						</li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<?php wp_footer(); ?>
	<script src="<?php echo site_url(); ?>/wp-content/themes/dwp/assets/js/jquery.min.js"></script>
	<script src="<?php echo site_url(); ?>/wp-content/themes/dwp/assets/js/slick.min.js"></script>
	<script src="<?php echo site_url(); ?>/wp-content/themes/dwp/assets/js/custom.js"></script>
</body>
</html>