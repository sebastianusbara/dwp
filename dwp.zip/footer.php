	</main>
	<footer class="main-footer">
		
	</footer>
	<?php wp_footer(); ?>
	<script src="<?php echo site_url(); ?>/wp-content/themes/dwp/assets/js/jquery.min.js"></script>
	<script src="<?php echo site_url(); ?>/wp-content/themes/dwp/assets/js/custom.js"></script>
</body>
</html>