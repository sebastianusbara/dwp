$('.main-nav').on('click', '.nav-btn', function(event) {
	$('.site-menu').toggle();
});